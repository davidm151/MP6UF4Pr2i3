/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javabeans;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.beans.PropertyVetoException;
import java.io.Serializable;
import java.util.Properties;
import java.beans.VetoableChangeListener;
import java.beans.VetoableChangeSupport;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author profe
 */
public class NewBean implements Serializable, VetoableChangeListener {

    private Connection conn = null;
    private String propsDB;
    private String insert;
    private int id;
    private String delete;
    private String select;
    private String update;
    private String close;
    private Statement statement;
    private String createtable;
    private ResultSet rs;

    public static final String PROP_UPDATE = "update";
    public static final String PROP_PROPSDB = "propsDB";
    public static final String PROP_SELECT = "select";
    public static final String PROP_DELETE = "delete";
    public static final String PROP_CLOSE = "close";
    public static final String PROP_INSERT = "insert";
    public static final String PROP_CREATETABLE = "createtable";

    public ResultSet getRs() {
        return rs;
    }

    /**
     * Get the value of close
     *
     * @return the value of close
     */
    public String getClose() {
        return close;
    }

    /**
     * Set the value of close
     *
     * @param close new value of close
     * @throws java.beans.PropertyVetoException
     */
    public void setClose(String close) throws PropertyVetoException {
        String oldClose = this.close;
        vetoableChangeSupport.fireVetoableChange(PROP_CLOSE, oldClose, close);
        this.close = close;
    }

    /**
     * Get the value of update
     *
     * @return the value of update
     */
    public String getUpdate() {
        return update;
    }

    /**
     * Set the value of update
     *
     * @param update new value of update
     * @throws java.beans.PropertyVetoException
     */
    public void setUpdate(String update) throws PropertyVetoException {
        String oldUpdate = this.update;
        vetoableChangeSupport.fireVetoableChange(PROP_UPDATE, oldUpdate, update);
        this.update = update;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    /**
     * Get the value of insert
     *
     * @return the value of insert
     */
    public String getInsert() {
        return insert;
    }

    /**
     * Set the value of insert
     *
     * @param insert new value of insert
     * @throws java.beans.PropertyVetoException
     */
    public void setInsert(String insert) throws PropertyVetoException {
        String oldInsert = this.insert;
        vetoableChangeSupport.fireVetoableChange(PROP_INSERT, oldInsert, insert);
        this.insert = insert;
    }

    /**
     * Get the value of delete
     *
     * @return the value of delete
     */
    public String getDelete() {
        return delete;
    }

    /**
     * Set the value of delete
     *
     * @param delete new value of delete
     * @throws java.beans.PropertyVetoException
     */
    public void setDelete(String delete) throws PropertyVetoException {
        String oldDelete = this.delete;
        vetoableChangeSupport.fireVetoableChange(PROP_DELETE, oldDelete, delete);
        this.delete = delete;
    }

    /**
     * Get the value of createtable
     *
     * @return the value of createtable
     */
    public String getCreatetable() {
        return createtable;
    }

    /**
     * Set the value of createtable
     *
     * @param createtable new value of createtable
     */
    public void setCreatetable(String createtable) throws PropertyVetoException {
        String oldCreatetable = this.createtable;
        vetoableChangeSupport.fireVetoableChange(PROP_CREATETABLE, oldCreatetable, createtable);
        this.createtable = createtable;
    }

    private transient final PropertyChangeSupport propertyChangeSupport = new PropertyChangeSupport(this);

    /**
     * Add PropertyChangeListener.
     *
     * @param listener
     */
    public void addPropertyChangeListener(PropertyChangeListener listener) {
        propertyChangeSupport.addPropertyChangeListener(listener);
    }

    /**
     * Remove PropertyChangeListener.
     *
     * @param listener
     */
    public void removePropertyChangeListener(PropertyChangeListener listener) {
        propertyChangeSupport.removePropertyChangeListener(listener);
    }

    public String getPropsDB() {
        return propsDB;
    }

    public Connection getConn() {
        return conn;
    }

    public void setPropsDB(String propsDB) throws PropertyVetoException {
        String oldPropsDB = this.propsDB;
        vetoableChangeSupport.fireVetoableChange(PROP_PROPSDB, oldPropsDB, propsDB);
        this.propsDB = propsDB;

    }

    public void setSelect(String select) throws PropertyVetoException {
        String oldselect = this.select;
        vetoableChangeSupport.fireVetoableChange(PROP_SELECT, oldselect, select);
        this.select = select;

    }

    private transient final VetoableChangeSupport vetoableChangeSupport = new VetoableChangeSupport(this);

    public void addVetoableChangeListener(VetoableChangeListener listener) {
        vetoableChangeSupport.addVetoableChangeListener(listener);
    }

    public void removeVetoableChangeListener(VetoableChangeListener listener) {
        vetoableChangeSupport.removeVetoableChangeListener(listener);
    }

    public NewBean() {
        this.addVetoableChangeListener(this);
    }

    @Override
    public void vetoableChange(PropertyChangeEvent evt) throws PropertyVetoException {

        if (evt.getPropertyName().equals(NewBean.PROP_PROPSDB)) {
            Properties properties = new Properties();
            try {
                properties.load(new FileInputStream((String) evt.getNewValue()));
                String url = (String) properties.get("url");
                String user = (String) properties.get("usuari");
                String pass = (String) properties.get("password");
                conn = DriverManager.getConnection(url, user, pass);
                System.out.println("Conectat en exit");
            } catch (IOException | SQLException ex) {
                throw new PropertyVetoException("", evt);
            }
        }
        if (evt.getPropertyName().equals(NewBean.PROP_CREATETABLE)) {
            try {
                Statement statement = conn.createStatement();
                statement.executeUpdate((String) evt.getNewValue());
            } catch (SQLException ex) {
                throw new PropertyVetoException("", evt);
            }
        }
        if (evt.getPropertyName().equals(NewBean.PROP_DELETE)) {
            try {
                Statement statement = conn.createStatement();
                statement.executeUpdate((String) evt.getNewValue());
            } catch (SQLException ex) {
                throw new PropertyVetoException("", evt);
            }
        }
        if (evt.getPropertyName().equals(NewBean.PROP_INSERT)) {
            try {
                conn.setAutoCommit(false);
                Statement statement = conn.createStatement();
                statement.executeUpdate((String) evt.getNewValue());
                conn.commit();
            } catch (SQLException ex) {
                 try {
                    conn.rollback();
                } catch (SQLException ex1) {
                    Logger.getLogger(NewBean.class.getName()).log(Level.SEVERE, null, ex1);
                }
            }finally{
                try {
                    conn.setAutoCommit(true);
                } catch (SQLException ex) {
                    Logger.getLogger(NewBean.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        if (evt.getPropertyName().equals(NewBean.PROP_SELECT)) {
            try {
                Statement statement = conn.createStatement();
                String x = (String) evt.getNewValue();
                rs = statement.executeQuery(x);
            } catch (Exception ex) {
                 throw new PropertyVetoException("", evt);
            }
        }
        if (evt.getPropertyName().equals(NewBean.PROP_UPDATE)) {
            try {
                Statement statement = conn.createStatement();
                statement.executeUpdate((String) evt.getNewValue());
            } catch (Exception ex) {
                throw new PropertyVetoException("", evt);
            }
        }
        if (evt.getPropertyName().equals(NewBean.PROP_CLOSE)) {
            try {
                conn.close();
            } catch (SQLException ex) {
                throw new PropertyVetoException("", evt);
            }
        }
    }
}
